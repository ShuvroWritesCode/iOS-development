var userName = "ShuvroWritesCode"
let accountId = 2000123

userName = "Shuvro Writes Code"

var numberOfLoginsInADay: Int = 34

var name, email, address: String
var BTCValue, EthValue: Double

name = "Shuvro"
email = "abc012@xyz.com"
address = "Dhaka, Bangladesh"

BTCValue = 1239.234
EthValue = 9991233.012345678

print(userName, accountId, numberOfLoginsInADay, name, email, address, BTCValue, EthValue)

